#include<stdio>
int main() {
  int n=10; 
  
  if(n%2 == 0) printf("%d is an even number", n);
  else if(n%2 == 1) printf("%d is an odd number", n);
  else print("The number you have entered is an invalid number");
  
  return 0;
}